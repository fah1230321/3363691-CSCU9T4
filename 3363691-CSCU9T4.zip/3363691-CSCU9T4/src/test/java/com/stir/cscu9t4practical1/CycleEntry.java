package com.stir.cscu9t4practical1;

public class CycleEntry {

    public CycleEntry(String string, int i, int j, int k, int l, int m, int n, int o, String string2, String string3) {
    }

    public String getEntry() {
        throw new UnsupportedOperationException("Unimplemented method 'getEntry'");
    }

    public String getTempo() {
        throw new UnsupportedOperationException("Unimplemented method 'getTempo'");
    }

    public String getTerrain() {
        throw new UnsupportedOperationException("Unimplemented method 'getTerrain'");
    }

    public float getDistance() {
        throw new UnsupportedOperationException("Unimplemented method 'getDistance'");
    }

    public int getSec() {
        throw new UnsupportedOperationException("Unimplemented method 'getSec'");
    }

    public int getMin() {
        throw new UnsupportedOperationException("Unimplemented method 'getMin'");
    }

    public int getHour() {
        throw new UnsupportedOperationException("Unimplemented method 'getHour'");
    }

    public int getYear() {
        throw new UnsupportedOperationException("Unimplemented method 'getYear'");
    }

    public int getMonth() {
        throw new UnsupportedOperationException("Unimplemented method 'getMonth'");
    }

    public int getDay() {
        throw new UnsupportedOperationException("Unimplemented method 'getDay'");
    }

    public String getName() {
        throw new UnsupportedOperationException("Unimplemented method 'getName'");
    }

}
