package com.stir.cscu9t4practical1;

public class SprintEntry {

    public SprintEntry(String string, int i, int j, int k, int l, int m, int n, int o, int p, int q) {
    }

    public String getName() {
        throw new UnsupportedOperationException("Unimplemented method 'getName'");
    }

    public int getDay() {
        throw new UnsupportedOperationException("Unimplemented method 'getDay'");
    }

    public String getEntry() {
        throw new UnsupportedOperationException("Unimplemented method 'getEntry'");
    }

    public int getRecovery() {
        throw new UnsupportedOperationException("Unimplemented method 'getRecovery'");
    }

    public int getMonth() {
        throw new UnsupportedOperationException("Unimplemented method 'getMonth'");
    }

    public int getYear() {
        throw new UnsupportedOperationException("Unimplemented method 'getYear'");
    }

    public int getHour() {
        throw new UnsupportedOperationException("Unimplemented method 'getHour'");
    }

    public int getMin() {
        throw new UnsupportedOperationException("Unimplemented method 'getMin'");
    }

    public int getSec() {
        throw new UnsupportedOperationException("Unimplemented method 'getSec'");
    }

    public float getDistance() {
        throw new UnsupportedOperationException("Unimplemented method 'getDistance'");
    }

    public int getRepetitions() {
        throw new UnsupportedOperationException("Unimplemented method 'getRepetitions'");
    }

}
